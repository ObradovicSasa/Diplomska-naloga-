function g = fnRotateG(om, t, g0)

if nargin ==3
    g(1,:) = g0;
else
    g(1,:) = [0 0 1];
end
%% rotacija za minus kot v referencnem sistemu
for i = 1:length(om)-1
    v = om(i,:);
    deltaT = t(i+1)-t(i);
    phi = -norm(v)*deltaT;
    v = v/norm(v);    
    R = rotationmat3D(phi,v);
    g(i+1,:) = (R*g(i,:)')';
end

%% rotacija za plus kot v sistemu senzorja
% for i = 1:length(om)-1
%     v = om(i,:);
%     deltaT = t(i+1)-t(i);
%     phi = norm(v)*deltaT;
%     v = v/norm(v);    
%     R = rotationmat3D(phi,v);
%     S = [g(i,:); 0 0 0; 0 0 0]*R;
%     g(i+1,:) = S(1,:);
% end