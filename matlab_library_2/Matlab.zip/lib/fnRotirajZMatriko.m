function S_out = fnRotirajZMatriko(S_in,R)

S_out = S_in*R;