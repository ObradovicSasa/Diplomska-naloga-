function M = fnMnoziMatriki(M1, M2)

M = M1*M2;