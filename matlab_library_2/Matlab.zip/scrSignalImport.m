ACCDATA      = readtable('data/Meritev1Acc.csv');
GYRODATA     = readtable('data/Meritev2Acc.csv');

[acc, om, ~] = fnSyncAccOmMW(ACCDATA, GYRODATA, 200);
figure;
subplot(211),plot(t/60,acc)
subplot(212),plot(t/60,om)

fig1 = figure;
subplot(211),plot(acc)
subplot(212),plot(om)
[x, y] = ginput(4);
close(fig1)
nCalStart    = x(1); nCalEnd       = x(2);
nStart       = x(3); nEnd       = x(4);

%% preprosta kalibracija ziroskopa
[omOffset, omCal]   = fnOffset(om, [nStartCal nEndCal], [0 0 0]);
[b, a]              = butter(30, 30/fs*2);
omCal               = filtfilt(b, a, omCal);
%% osnovna orientacija vektorja gravitacije
g0                  = mean(acc(nStart:nStart+20,:));
%% rotacija vektorja g
g                   = fnRotateG(om(nStart:nEnd,:)./180*pi, t(nStart:nEnd)/1000, g0);
gCal                = fnRotateG(omCal(nStart:nEnd,:)./180*pi, t(nStart:nEnd)/1000, g0);
fnPlotGOrient(t(nStart:nEnd,:), acc(nStart:nEnd,:) , g, gCal, 1);
acos(g(end,:)*acc(nEnd,:)'/norm(g(end,:))/norm(acc(nEnd,:)))*180/pi
acos(gCal(end,:)*acc(nEnd,:)'/norm(gCal(end,:))/norm(acc(nEnd,:)))*180/pi

[RkvCal, RtrCal]    = fnRotateSensor(omCal(nStart:nEnd,:)/180*pi, t(nStart:nEnd)/1000); 
%fnAnimirajRotacijo(RkvCal, t(nStart:nEnd,:), 20);


S.acc    = acc(nStart:nEnd,:);
S.t      = t(nStart:nEnd,:);
S.om     = om(nStart:nEnd,:);
S.omCal  = omCal;
S.RkvCal = RkvCal;

save('Meritev1.mat', 'S')


